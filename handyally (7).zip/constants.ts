import { Service, Testimonial } from './types';

export const BUSINESS_INFO = {
  name: "HandyAlly",
  owner: "Justin Zereneh",
  phone: "647-451-6961",
  email: "justinzereneh@handyally.com", // Updated to Google Workspace email
  location: "Vaughan, Ontario",
  experience: "20+",
  projectValue: "$2.7M",
  baseRate: 125, // per hour per person
  snowRemovalEvent: 100,
  snowRemovalSeason: 1500,
};

export const SERVICES: Service[] = [
  {
    id: 'handyperson',
    title: 'Handyperson Services',
    shortDescription: 'Versatile repairs and maintenance for your home.',
    fullDescription: 'Our core service covering a wide range of home repairs, from hanging shelves to fixing loose cabinets. We bring the tools and the expertise.',
    iconName: 'Hammer',
    priceModel: '$125/hr',
    whatsIncluded: ['Small repairs', 'Mounting/Hanging', 'Basic fixes', 'Door adjustments'],
    whatsNotIncluded: ['Major structural changes'],
    category: 'General'
  },
  {
    id: 'carpenter',
    title: 'Carpenter',
    shortDescription: 'Trim, molding, cabinetry and wood structures.',
    fullDescription: 'Skilled carpentry for baseboards, crown molding, cabinetry repairs, and custom wood projects.',
    iconName: 'Ruler',
    priceModel: '$125/hr',
    whatsIncluded: ['Baseboards', 'Trim work', 'Cabinet repair', 'Shelving units'],
    whatsNotIncluded: ['Structural framing without permit'],
    category: 'General'
  },
  {
    id: 'landscaper',
    title: 'Landscaper',
    shortDescription: 'Garden maintenance and yard improvements.',
    fullDescription: 'Professional landscaping services to keep your curb appeal high. Planting, trimming, and garden bed maintenance.',
    iconName: 'Shovel',
    priceModel: '$125/hr',
    whatsIncluded: ['Planting', 'Trimming', 'Garden cleanup', 'Mulching'],
    whatsNotIncluded: ['Large tree removal'],
    category: 'Exterior'
  },
  {
    id: 'smart-home-camera',
    title: 'Smart Home & Camera',
    shortDescription: 'Installation of security cameras and smart devices.',
    fullDescription: 'Secure your property and upgrade your home tech. We install wired/wireless cameras, smart locks, and thermostats.',
    iconName: 'Cctv',
    priceModel: '$125/hr',
    whatsIncluded: ['Camera mounting', 'Cable running', 'Smart lock setup', 'Doorbell install'],
    whatsNotIncluded: ['Monitoring subscription'],
    category: 'Technical'
  },
  {
    id: 'painting',
    title: 'Painting',
    shortDescription: 'Interior and exterior painting services.',
    fullDescription: 'Professional painting for rooms, trim, or touch-ups. We ensure smooth finishes and clean lines.',
    iconName: 'PaintRoller',
    priceModel: '$125/hr',
    whatsIncluded: ['Wall painting', 'Trim painting', 'Priming', 'Minor patching'],
    whatsNotIncluded: ['Whole house exterior (consultation needed)'],
    category: 'General'
  },
  {
    id: 'concrete',
    title: 'Concrete Work',
    shortDescription: 'Small slab pouring and concrete repairs.',
    fullDescription: 'Repairing cracks, pouring small pads for sheds or walkways, and general concrete maintenance.',
    iconName: 'BrickWall', // Lucide icon fallback
    priceModel: '$125/hr',
    whatsIncluded: ['Crack repair', 'Small pads', 'Walkway repairs'],
    whatsNotIncluded: ['Large driveways'],
    category: 'Exterior'
  },
  {
    id: 'flooring',
    title: 'Flooring',
    shortDescription: 'Installation and repair of various floor types.',
    fullDescription: 'Expert installation of laminate, vinyl, hardwood, or tile flooring for your home.',
    iconName: 'LayoutGrid',
    priceModel: '$125/hr',
    whatsIncluded: ['Laminate install', 'Vinyl plank', 'Tile repair', 'Baseboard reinstall'],
    whatsNotIncluded: ['Carpet stretching'],
    category: 'General'
  },
  {
    id: 'stone-work',
    title: 'Exterior Stone Work',
    shortDescription: 'Interlock repair and stone features.',
    fullDescription: 'Enhance your exterior with stone work repairs, interlock relaying, and decorative stone features.',
    iconName: 'Mountain',
    priceModel: '$125/hr',
    whatsIncluded: ['Interlock releveling', 'Stone veneer repair', 'Garden wall stacking'],
    whatsNotIncluded: ['Major retaining walls (engineering required)'],
    category: 'Exterior'
  },
  {
    id: 'snow-removal',
    title: 'Snow Removal',
    shortDescription: 'Winter clearing for driveways and walkways.',
    fullDescription: 'Keep your property safe and accessible during the harsh Ontario winter.',
    iconName: 'Snowflake',
    priceModel: '$125/hr',
    whatsIncluded: ['Driveway clearing', 'Walkway clearing', 'Salting'],
    whatsNotIncluded: ['Roof snow removal'],
    category: 'Exterior'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Sarah M.",
    location: "Woodbridge",
    text: "Justin saved us! Had a pipe burst and he was there within the hour. Professional and calm.",
    rating: 5
  },
  {
    id: 2,
    name: "Mike T.",
    location: "Kleinburg",
    text: "Used HandyAlly for mounting 3 TVs and assembling IKEA furniture. Flawless work.",
    rating: 5
  },
  {
    id: 3,
    name: "Elena R.",
    location: "Vaughan",
    text: "The flat rate pricing is so refreshing. No hidden fees. Highly recommend for seniors.",
    rating: 5
  }
];

export const BLOG_POSTS = [
  {
    id: 1,
    title: "5 Signs You Need Electrical Troubleshooting ASAP",
    excerpt: "Flickering lights? Warm outlets? Don't ignore these warning signs that could indicate a serious fire hazard in your home.",
    date: "Oct 12, 2023",
    category: "Safety",
    image: "https://picsum.photos/id/1015/800/600"
  },
  {
    id: 2,
    title: "Winter Proofing Your Vaughan Home: A Checklist",
    excerpt: "The Canadian winter is harsh. Here is your essential checklist to prevent frozen pipes and drafts before the snow hits.",
    date: "Nov 05, 2023",
    category: "Maintenance",
    image: "https://picsum.photos/id/1036/800/600"
  },
  {
    id: 3,
    title: "DIY vs. Pro: When to Call a Handyman",
    excerpt: "Some jobs are fun weekend projects. Others are disasters waiting to happen. Learn where to draw the line.",
    date: "Jan 15, 2024",
    category: "Tips",
    image: "https://picsum.photos/id/1062/800/600"
  },
  {
    id: 4,
    title: "Top Smart Home Upgrades for 2024",
    excerpt: "From video doorbells to smart thermostats, these are the best value upgrades to modernize your home this year.",
    date: "Feb 20, 2024",
    category: "Technology",
    image: "https://picsum.photos/id/1075/800/600"
  },
  {
    id: 5,
    title: "How to Maintain Your Deck Through Canadian Seasons",
    excerpt: "Wood rot is the enemy. Learn the proper cleaning and sealing schedule to keep your deck looking new for decades.",
    date: "Mar 10, 2024",
    category: "Exterior",
    image: "https://picsum.photos/id/1040/800/600"
  }
];

export const LOYALTY_TIERS = [
  {
    name: "Bronze Ally",
    requirement: "Join after 1st Service",
    benefits: ["5% Off Next Booking", "Seasonal Maintenance Newsletter", "Priority Email Support"],
    colorClass: "bg-orange-50 border-orange-200 text-orange-900",
    badgeColor: "bg-orange-100 text-orange-700"
  },
  {
    name: "Silver Ally",
    requirement: "3+ Services Completed",
    benefits: ["10% Off Labor Rates", "Priority Booking Window (24hr)", "Free Annual Home Safety Checkup"],
    colorClass: "bg-slate-100 border-slate-300 text-slate-900",
    badgeColor: "bg-slate-200 text-slate-700"
  },
  {
    name: "Gold Ally",
    requirement: "5+ Services or $2k+ Spend",
    benefits: ["15% Off All Labor", "Waived Emergency Dispatch Fees", "Direct Mobile Access to Justin", "Free Snow Removal Event (1/yr)"],
    colorClass: "bg-yellow-50 border-yellow-200 text-yellow-900",
    badgeColor: "bg-yellow-100 text-yellow-700"
  }
];