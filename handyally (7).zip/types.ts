export interface Service {
  id: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  priceModel: string;
  whatsIncluded: string[];
  whatsNotIncluded: string[];
  category: 'General' | 'Technical' | 'Exterior' | 'Emergency';
}

export interface Testimonial {
  id: number;
  name: string;
  location: string;
  text: string;
  rating: number;
}

export interface QuoteFormData {
  serviceType: string;
  description: string;
  preferredDate: string;
  crewSize: '1' | '2';
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  files: FileList | null;
}

export interface BookingData {
  date: Date | null;
  timeSlot: string;
  serviceId: string;
  hours: number;
  addLaborer: boolean;
}