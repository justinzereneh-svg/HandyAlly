# HandyAlly Website

Professional handyman services website built with React, TypeScript, Tailwind CSS, and Google Gemini AI.

## 🚀 Getting Started

1.  **Install Dependencies**
    ```bash
    npm install
    ```

2.  **Set up API Keys**
    Create a `.env` file in the root directory (if running locally) or add these to your Vercel/Netlify Environment Variables:
    ```
    VITE_API_KEY=your_google_gemini_api_key
    ```
    *(Note: The current code uses `process.env.API_KEY` for the demo environment. For local Vite development, you may need to update `services/gemini.ts` to use `import.meta.env.VITE_API_KEY`)*

3.  **Run Development Server**
    ```bash
    npm run dev
    ```

## 📦 Deployment

### Deploy to Vercel (Recommended)
1.  Push this code to a GitHub repository.
2.  Go to Vercel.com and "Import Project".
3.  Select your repository.
4.  Add your Environment Variables.
5.  Click Deploy.

## 🛠 Tech Stack
*   **Frontend:** React 19, TypeScript, Vite
*   **Styling:** Tailwind CSS
*   **AI:** Google Gemini 2.5 Flash (for Quotes & Address Autocomplete)
*   **Email:** EmailJS (Booking Confirmations)
*   **Icons:** Lucide React

## 📝 License
Copyright © 2024 HandyAlly. All rights reserved.
