import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Star, Shield, Clock, Wrench } from 'lucide-react';
import { SERVICES, TESTIMONIALS } from '../constants';

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white pt-20 pb-32 md:pt-32 md:pb-40 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
           <img 
             src="https://picsum.photos/id/1062/1920/1080" 
             alt="Handyman working" 
             className="w-full h-full object-cover"
           />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/90 to-transparent"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <div className="inline-block bg-accent-500/20 text-accent-400 px-3 py-1 rounded-full text-sm font-bold mb-6 border border-accent-500/30">
              Top Rated in Vaughan & GTA
            </div>
            <h1 className="font-heading text-5xl md:text-6xl font-bold leading-tight mb-6">
              The Friendly Handyman <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">You Can Trust.</span>
            </h1>
            <p className="text-lg text-slate-300 mb-8 max-w-lg leading-relaxed">
              From smart home installs to emergency repairs. 20+ years of experience delivering premium home services with a smile.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/quote" className="px-8 py-4 bg-primary-600 hover:bg-primary-500 rounded-xl font-bold text-lg shadow-xl shadow-primary-900/50 transition flex items-center justify-center gap-2">
                Get a Free Quote <ArrowRight size={20} />
              </Link>
              <Link to="/book" className="px-8 py-4 bg-white text-slate-900 hover:bg-slate-100 rounded-xl font-bold text-lg shadow-xl transition flex items-center justify-center">
                Book Service
              </Link>
            </div>

            <div className="mt-10 flex items-center gap-4 text-sm text-slate-400">
              <div className="flex items-center gap-1"><CheckCircle size={16} className="text-green-400" /> Fully Insured</div>
              <div className="flex items-center gap-1"><CheckCircle size={16} className="text-green-400" /> WSIB Aware</div>
              <div className="flex items-center gap-1"><CheckCircle size={16} className="text-green-400" /> 20+ Years Exp</div>
            </div>
          </div>
        </div>
      </section>

      {/* Funnel Options */}
      <section className="relative -mt-16 container mx-auto px-4 z-20 mb-20">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Instant Quote Card */}
          <div className="bg-white p-8 rounded-2xl shadow-xl border-b-4 border-primary-500 hover:transform hover:-translate-y-1 transition duration-300">
            <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-lg flex items-center justify-center mb-4">
              <Clock size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Get a Quote</h3>
            <p className="text-slate-500 text-sm mb-4">Tell us about your project. Use our AI estimator to get a rough idea of hours instantly.</p>
            <Link to="/quote" className="text-primary-600 font-bold text-sm hover:underline flex items-center gap-1">Start Quote <ArrowRight size={16}/></Link>
          </div>

          {/* Book Now Card */}
          <div className="bg-white p-8 rounded-2xl shadow-xl border-b-4 border-accent-500 hover:transform hover:-translate-y-1 transition duration-300">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-lg flex items-center justify-center mb-4">
              <Wrench size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Book Service</h3>
            <p className="text-slate-500 text-sm mb-4">Ready to go? View our calendar, pick a slot, and secure your handyman.</p>
            <Link to="/book" className="text-accent-600 font-bold text-sm hover:underline flex items-center gap-1">Book Appointment <ArrowRight size={16}/></Link>
          </div>

          {/* Emergency Card */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-8 rounded-2xl shadow-xl border-b-4 border-red-500 hover:transform hover:-translate-y-1 transition duration-300 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">URGENT</div>
            <div className="w-12 h-12 bg-white/10 text-red-400 rounded-lg flex items-center justify-center mb-4">
              <Shield size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Emergency?</h3>
            <p className="text-slate-400 text-sm mb-4">Same-day service for urgent repairs. 60-120 minute arrival window.</p>
            <Link to="/emergency" className="text-white font-bold text-sm hover:underline flex items-center gap-1">Call Now <ArrowRight size={16}/></Link>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="container mx-auto px-4 mb-20">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mb-4">Expertise You Can Count On</h2>
          <p className="text-slate-600">Whether it's a small fix or a renovation project, we have the tools and experience to get it done right.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.slice(0, 4).map((service) => (
            <Link to={`/services/${service.id}`} key={service.id} className="group bg-slate-50 rounded-xl p-6 hover:bg-white hover:shadow-xl transition border border-transparent hover:border-primary-100">
              <div className="mb-4">
                 <h3 className="font-bold text-lg group-hover:text-primary-600 transition">{service.title}</h3>
                 <p className="text-xs text-primary-500 font-semibold mt-1">{service.priceModel}</p>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed mb-4">
                {service.shortDescription}
              </p>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 group-hover:text-primary-600 flex items-center gap-1">
                Learn More <ArrowRight size={12} />
              </span>
            </Link>
          ))}
        </div>
        
        <div className="mt-10 text-center">
          <Link to="/services" className="inline-block px-6 py-3 border-2 border-slate-200 rounded-full font-bold text-slate-600 hover:border-primary-600 hover:text-primary-600 transition">View All Services</Link>
        </div>
      </section>

      {/* Social Proof */}
      <section className="bg-primary-50 py-20">
        <div className="container mx-auto px-4">
           <h2 className="text-3xl font-heading font-bold text-center mb-12">Loved by Locals</h2>
           <div className="grid md:grid-cols-3 gap-8">
             {TESTIMONIALS.map((t) => (
               <div key={t.id} className="bg-white p-8 rounded-xl shadow-sm">
                 <div className="flex text-yellow-400 mb-4">
                   {[...Array(t.rating)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                 </div>
                 <p className="text-slate-600 italic mb-6">"{t.text}"</p>
                 <div>
                   <p className="font-bold text-slate-900">{t.name}</p>
                   <p className="text-xs text-slate-500">{t.location}</p>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </section>

      {/* Before/After CTA */}
      <section className="container mx-auto px-4 py-20 flex flex-col md:flex-row items-center gap-12">
         <div className="flex-1">
            <img src="https://picsum.photos/id/1035/800/600" alt="Project Gallery" className="rounded-2xl shadow-2xl rotate-2 hover:rotate-0 transition duration-500" />
         </div>
         <div className="flex-1">
           <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">See the Transformation</h2>
           <p className="text-slate-600 text-lg mb-8">
             We take pride in our work. Browse our gallery to see real examples of repairs, installations, and renovations across Vaughan.
           </p>
           <Link to="/gallery" className="text-primary-600 font-bold text-lg hover:underline flex items-center gap-2">
             View Project Gallery <ArrowRight />
           </Link>
         </div>
      </section>
    </div>
  );
};

export default Home;