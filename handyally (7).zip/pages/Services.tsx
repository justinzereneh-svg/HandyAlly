import React from 'react';
import { Link } from 'react-router-dom';
import { Check, ArrowRight } from 'lucide-react';
import { SERVICES } from '../constants';

const Services = () => {
  return (
    <div className="pb-20">
      <div className="bg-slate-50 py-16 mb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-heading font-bold text-slate-900 mb-4">Our Services</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">Professional, insured, and reliable. Choose a category below to get started.</p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="grid gap-8">
          {SERVICES.map((service) => (
            <div key={service.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition flex flex-col md:flex-row">
              <div className="md:w-1/3 h-64 md:h-auto bg-slate-200 relative">
                 <img 
                    src={`https://picsum.photos/seed/${service.id}/600/400`} 
                    alt={service.title} 
                    className="w-full h-full object-cover absolute inset-0"
                 />
                 <div className="absolute top-4 left-4 bg-white/90 px-3 py-1 rounded-full text-xs font-bold shadow-sm">
                    {service.category}
                 </div>
              </div>
              <div className="p-8 md:w-2/3 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <h2 className="text-2xl font-bold font-heading text-slate-900">{service.title}</h2>
                    <span className="bg-primary-50 text-primary-700 px-3 py-1 rounded-lg text-sm font-semibold">
                      {service.priceModel}
                    </span>
                  </div>
                  <p className="text-slate-600 mb-6">{service.fullDescription}</p>
                  
                  <div className="grid sm:grid-cols-2 gap-4 mb-8">
                    <div>
                      <h4 className="font-bold text-sm mb-2 text-slate-800">What's Included:</h4>
                      <ul className="space-y-1">
                        {service.whatsIncluded.map((item, i) => (
                          <li key={i} className="text-sm text-slate-600 flex items-center gap-2">
                            <Check size={14} className="text-green-500" /> {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-bold text-sm mb-2 text-slate-800">Not Included:</h4>
                       <ul className="space-y-1">
                        {service.whatsNotIncluded.map((item, i) => (
                          <li key={i} className="text-sm text-slate-500 flex items-center gap-2">
                            <span className="w-3.5 h-3.5 rounded-full border border-slate-300 flex items-center justify-center text-[8px]">x</span> {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 mt-auto">
                  <Link to="/quote" className="flex-1 bg-primary-600 text-white py-3 rounded-lg font-bold text-center hover:bg-primary-700 transition">
                    Get a Quote
                  </Link>
                  <Link to="/book" className="flex-1 bg-slate-100 text-slate-900 py-3 rounded-lg font-bold text-center hover:bg-slate-200 transition">
                    Book Now
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;