import React from 'react';
import { BUSINESS_INFO } from '../constants';

const About = () => {
  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
             <h1 className="text-4xl font-heading font-bold mb-4">The Man Behind the Tools</h1>
             <div className="w-20 h-1 bg-primary-600 mx-auto rounded"></div>
          </div>

          <div className="flex flex-col md:flex-row gap-12 items-center mb-16">
             <div className="md:w-1/2">
                <img 
                  src="https://picsum.photos/id/1005/600/800" 
                  alt="Justin Zereneh" 
                  className="rounded-2xl shadow-xl"
                />
             </div>
             <div className="md:w-1/2">
               <h2 className="text-3xl font-bold mb-4 text-slate-900">Hi, I'm {BUSINESS_INFO.owner}.</h2>
               <p className="text-slate-600 leading-relaxed mb-4">
                 With over 20 years of experience in the construction and maintenance industry, I've overseen <strong>$2.7 million</strong> worth of projects in just the last few quarters. But numbers only tell half the story.
               </p>
               <p className="text-slate-600 leading-relaxed mb-4">
                 HandyAlly was born out of a desire to bring professional, big-project reliability to everyday home repairs in Vaughan. I noticed that homeowners often struggle to find someone trustworthy for "small" jobs—mounting a TV, fixing a fence, or upgrading smart home tech.
               </p>
               <p className="text-slate-600 leading-relaxed mb-6">
                 My mission is simple: <strong>Be the ally your home needs.</strong> Friendly service, transparent pricing, and quality work that stands the test of time.
               </p>
               <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
                 <h3 className="font-bold mb-2">Why Vaughan Chooses HandyAlly:</h3>
                 <ul className="list-disc list-inside space-y-2 text-slate-600">
                   <li>Fully Equipped Mobile Workshop</li>
                   <li>WSIB-Aware & Safety First</li>
                   <li>Respectful of your property (we wear boot covers!)</li>
                 </ul>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;