import { GoogleGenAI } from "@google/genai";

// Initialize Gemini client
// Note: In a real production app, this should be proxied through a backend
// to protect the API key. For this frontend demo, we use process.env.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const estimateJobEffort = async (description: string, serviceType: string): Promise<{ hours: number; explanation: string; recommendedCrew: number }> => {
  if (!process.env.API_KEY) {
     console.warn("No API Key found for Gemini.");
     return {
         hours: 2,
         explanation: "Standard estimation (AI unavailable).",
         recommendedCrew: 1
     };
  }

  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are an expert handyman estimator for "HandyAlly".
      Rate is $125/hr.
      Task Type: ${serviceType}
      User Description: "${description}"

      Estimate the number of hours this might take. Be realistic but safe.
      Recommend if 1 or 2 people are needed (2 people if heavy lifting or safety risk).

      Return ONLY a JSON object with this schema:
      {
        "hours": number,
        "explanation": "short string explaining why",
        "recommendedCrew": number (1 or 2)
      }
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini estimation failed:", error);
    return {
      hours: 3,
      explanation: "Based on average job times for this category.",
      recommendedCrew: 1
    };
  }
};

export const suggestAddresses = async (query: string): Promise<{address: string, postalCode: string}[]> => {
  if (!process.env.API_KEY || query.length < 4) {
      return [];
  }

  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Task: Address Autocomplete for Vaughan, Ontario and GTA.
      User Input: "${query}"
      
      Provide 3-5 real, valid street addresses in Vaughan, Woodbridge, Maple, Concord, or Toronto that closely match the input.
      If the input is vague, suggest prominent streets or locations in Vaughan.
      
      Return purely a JSON array of objects with this schema:
      [
        { "address": "123 Example St, Vaughan, ON", "postalCode": "L4K 1A1" }
      ]
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) return [];

    return JSON.parse(text);
  } catch (error) {
    console.error("Address autocomplete failed:", error);
    return [];
  }
};