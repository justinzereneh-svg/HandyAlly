import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Facebook, Instagram, Mail, Handshake, Code } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isEmergency = location.pathname === '/emergency';

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-800">
      {/* Top Bar */}
      <div className="bg-primary-900 text-white py-2 px-4 text-sm hidden md:flex justify-between items-center">
        <div className="flex gap-4">
          <span>Serving {BUSINESS_INFO.location} & GTA</span>
          <span className="flex items-center gap-1"><Phone size={14} /> {BUSINESS_INFO.phone}</span>
        </div>
        <div className="flex gap-3">
          <a href="#" className="hover:text-accent-400"><Facebook size={16} /></a>
          <a href="#" className="hover:text-accent-400"><Instagram size={16} /></a>
          <a href={`mailto:${BUSINESS_INFO.email}`} className="hover:text-accent-400"><Mail size={16} /></a>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-3">
             {/* Logo Icon */}
             <div className="w-11 h-11 rounded-full border-[2.5px] border-primary-600 flex items-center justify-center bg-white text-primary-600">
                <Handshake size={22} strokeWidth={2.5} />
             </div>
             <div>
               <h1 className="font-heading font-bold text-xl md:text-2xl tracking-tight leading-none">
                 <span className="text-primary-700">Handy</span><span className="text-accent-500">Ally</span>
               </h1>
               <p className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Reliable Home Services</p>
             </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-6 font-medium text-sm">
            <Link to="/" className="hover:text-primary-600 transition">Home</Link>
            <Link to="/services" className="hover:text-primary-600 transition">Services</Link>
            <Link to="/gallery" className="hover:text-primary-600 transition">Gallery</Link>
            <Link to="/blog" className="hover:text-primary-600 transition">Blog</Link>
            <Link to="/about" className="hover:text-primary-600 transition">About</Link>
            <Link to="/contact" className="hover:text-primary-600 transition">Contact</Link>
          </nav>

          <div className="hidden lg:flex items-center gap-4">
             <Link to="/quote" className="px-5 py-2 border-2 border-primary-600 text-primary-600 rounded-full font-semibold hover:bg-primary-50 transition">
               Get Quote
             </Link>
             <Link to="/book" className="px-5 py-2 bg-accent-500 text-white rounded-full font-semibold hover:bg-accent-600 shadow-lg shadow-accent-200 transition transform hover:-translate-y-0.5">
               Book Now
             </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="lg:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t absolute w-full">
            <nav className="flex flex-col p-4 gap-4 font-medium">
              <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
              <Link to="/services" onClick={() => setIsMenuOpen(false)}>Services</Link>
              <Link to="/gallery" onClick={() => setIsMenuOpen(false)}>Gallery</Link>
              <Link to="/blog" onClick={() => setIsMenuOpen(false)}>Blog</Link>
              <Link to="/loyalty" onClick={() => setIsMenuOpen(false)}>Loyalty Program</Link>
              <Link to="/about" onClick={() => setIsMenuOpen(false)}>About</Link>
              <Link to="/contact" onClick={() => setIsMenuOpen(false)}>Contact</Link>
              <hr />
              <Link to="/quote" onClick={() => setIsMenuOpen(false)} className="text-primary-600">Get a Quote</Link>
              <Link to="/book" onClick={() => setIsMenuOpen(false)} className="text-accent-600 font-bold">Book Now</Link>
              <Link to="/emergency" onClick={() => setIsMenuOpen(false)} className="text-red-600 font-bold uppercase flex items-center gap-2"><Phone size={16}/> Emergency Service</Link>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow relative">
        {children}
      </main>

      {/* Sticky Emergency/Book Mobile Bar */}
      {!isEmergency && (
        <div className="lg:hidden fixed bottom-0 left-0 w-full bg-white border-t shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] z-40 p-3 flex gap-3">
           <a href={`tel:${BUSINESS_INFO.phone}`} className="flex-1 bg-slate-800 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 text-sm">
             <Phone size={16} /> Call
           </a>
           <Link to="/book" className="flex-1 bg-accent-500 text-white py-3 rounded-lg font-bold flex justify-center items-center text-sm">
             Book Now
           </Link>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 pt-12 pb-20 lg:pb-6">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-heading font-bold text-2xl mb-4">
                <span className="text-white">Handy</span><span className="text-accent-500">Ally</span>
              </h3>
              <p className="text-sm leading-relaxed mb-4">
                Your trusted partner for home repairs and renovations in Vaughan and the GTA. Friendly, reliable, and professional.
              </p>
              <div className="flex gap-4">
                <a href="#" className="hover:text-white transition"><Facebook /></a>
                <a href="#" className="hover:text-white transition"><Instagram /></a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/services" className="hover:text-accent-400">General Handyman</Link></li>
                <li><Link to="/services" className="hover:text-accent-400">Electrical & Plumbing</Link></li>
                <li><Link to="/services" className="hover:text-accent-400">Carpentry</Link></li>
                <li><Link to="/services" className="hover:text-accent-400">Smart Home Setup</Link></li>
                <li><Link to="/services" className="hover:text-accent-400">Snow Removal</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-accent-400">About Justin</Link></li>
                <li><Link to="/gallery" className="hover:text-accent-400">Project Gallery</Link></li>
                <li><Link to="/blog" className="hover:text-accent-400">Expert Blog</Link></li>
                <li><Link to="/loyalty" className="hover:text-accent-400 text-yellow-400">Loyalty Program</Link></li>
                <li><Link to="/contact" className="hover:text-accent-400">Contact Us</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-4">Contact</h4>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start gap-3">
                  <Phone size={18} className="text-accent-500 shrink-0" />
                  <span>{BUSINESS_INFO.phone}</span>
                </li>
                <li className="flex items-start gap-3">
                  <Mail size={18} className="text-accent-500 shrink-0" />
                  <span>{BUSINESS_INFO.email}</span>
                </li>
                <li className="flex items-start gap-3">
                   <span className="w-4 h-4 rounded-full bg-green-500 mt-1 shrink-0"></span>
                   <span>Serving Vaughan, Woodbridge, Kleinburg, Concord, Maple</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
            <p>&copy; {new Date().getFullYear()} HandyAlly. All rights reserved.</p>
            <div className="flex items-center gap-4 opacity-50 hover:opacity-100 transition">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
                    <Code size={12} /> Developer Access
                </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};