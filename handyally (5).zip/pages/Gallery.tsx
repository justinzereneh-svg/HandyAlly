import React from 'react';

const Gallery = () => {
  // Simulating gallery images
  const images = [
    { id: 1, cat: 'Carpentry', desc: 'Custom built-in shelving' },
    { id: 2, cat: 'Electrical', desc: 'Modern light fixture install' },
    { id: 3, cat: 'Exterior', desc: 'Fence repair and staining' },
    { id: 4, cat: 'Smart Home', desc: 'Ring security setup' },
    { id: 5, cat: 'Mounting', desc: '75-inch TV mounting' },
    { id: 6, cat: 'Renovation', desc: 'Bathroom vanity update' },
  ];

  return (
    <div className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-heading font-bold mb-4">Our Work</h1>
          <p className="text-slate-600">A snapshot of recent projects completed in Vaughan.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((img) => (
            <div key={img.id} className="group relative overflow-hidden rounded-xl shadow-md cursor-pointer">
              <img 
                src={`https://picsum.photos/seed/${img.id + 10}/600/600`} 
                alt={img.desc}
                className="w-full h-72 object-cover transform group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition flex flex-col justify-end p-6">
                <span className="text-accent-400 text-xs font-bold uppercase tracking-wider">{img.cat}</span>
                <h3 className="text-white font-bold text-lg">{img.desc}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;