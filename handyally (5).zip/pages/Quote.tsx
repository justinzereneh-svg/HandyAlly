import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';
import { QuoteFormData } from '../types';
import { Camera, CheckCircle, Loader2, AlertCircle, Sparkles, Users } from 'lucide-react';
import { estimateJobEffort } from '../services/gemini';

const Quote = () => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEstimating, setIsEstimating] = useState(false);
  
  // AI Estimation State
  const [aiEstimate, setAiEstimate] = useState<{hours: number, explanation: string, recommendedCrew: number} | null>(null);

  const [formData, setFormData] = useState<QuoteFormData>({
    serviceType: '',
    description: '',
    preferredDate: '',
    crewSize: '2', // Default to 2 per new safety requirement
    contactName: '',
    contactEmail: '',
    contactPhone: '',
    address: '',
    files: null
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Trigger AI estimation when description loses focus or user clicks "Get Estimate"
  const handleGetEstimate = async () => {
    if (formData.description.length < 10 || !formData.serviceType) return;
    
    setIsEstimating(true);
    try {
      const result = await estimateJobEffort(formData.description, formData.serviceType);
      setAiEstimate(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsEstimating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setStep(4); // Success step
    }, 1500);
  };

  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            <span className={step >= 1 ? "text-primary-600" : ""}>Project</span>
            <span className={step >= 2 ? "text-primary-600" : ""}>Details</span>
            <span className={step >= 3 ? "text-primary-600" : ""}>Contact</span>
          </div>
          <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary-600 transition-all duration-500" 
              style={{ width: step === 4 ? '100%' : `${((step - 1) / 2) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {step === 1 && (
            <div className="animate-fadeIn">
              <h2 className="text-2xl font-bold mb-6 text-slate-900">What do you need help with?</h2>
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                {SERVICES.map(s => (
                  <label key={s.id} className={`border rounded-xl p-4 cursor-pointer transition hover:bg-slate-50 ${formData.serviceType === s.title ? 'border-primary-600 bg-primary-50 ring-1 ring-primary-600' : 'border-slate-200'}`}>
                    <input 
                      type="radio" 
                      name="serviceType" 
                      value={s.title}
                      checked={formData.serviceType === s.title}
                      onChange={handleInputChange}
                      className="hidden"
                    />
                    <div className="flex justify-between items-start">
                        <div className="font-bold text-slate-900">{s.title}</div>
                        <div className="text-xs font-bold text-primary-600 bg-primary-50 px-2 py-1 rounded">$125/hr</div>
                    </div>
                    <div className="text-xs text-slate-500 mt-1">{s.shortDescription}</div>
                  </label>
                ))}
              </div>
              <div className="flex justify-end">
                <button 
                  onClick={() => setStep(2)} 
                  disabled={!formData.serviceType}
                  className="bg-primary-600 text-white px-8 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary-700 transition"
                >
                  Next Step
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-fadeIn">
              <h2 className="text-2xl font-bold mb-2 text-slate-900">Tell us more</h2>
              <p className="text-slate-500 text-sm mb-6">Describe the problem or project. Be as specific as possible.</p>
              
              <div className="mb-6">
                <label className="block text-sm font-bold text-slate-700 mb-2">Description</label>
                <textarea 
                  name="description"
                  rows={4}
                  className="w-full border border-slate-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="E.g., 'I have a hole in the drywall about 4 inches wide in the living room...'"
                  value={formData.description}
                  onChange={handleInputChange}
                  onBlur={() => { if(formData.description.length > 10) handleGetEstimate() }}
                ></textarea>
                
                {/* AI Estimator Button */}
                <div className="mt-2 flex justify-end">
                   <button 
                     type="button"
                     onClick={handleGetEstimate}
                     disabled={isEstimating || formData.description.length < 10}
                     className="text-xs font-bold text-primary-600 flex items-center gap-1 hover:text-primary-700"
                   >
                     {isEstimating ? <Loader2 size={12} className="animate-spin"/> : <Sparkles size={12} />}
                     {isEstimating ? 'Analyzing...' : 'Get AI Estimate'}
                   </button>
                </div>

                {/* AI Estimate Result */}
                {aiEstimate && (
                   <div className="mt-4 bg-indigo-50 border border-indigo-100 p-4 rounded-lg">
                      <div className="flex items-start gap-3">
                        <Sparkles className="text-indigo-500 mt-1 shrink-0" size={18} />
                        <div>
                          <p className="text-sm font-bold text-indigo-900">AI Estimated Effort: ~{aiEstimate.hours} Hours</p>
                          <p className="text-xs text-indigo-700 mt-1">{aiEstimate.explanation}</p>
                        </div>
                      </div>
                   </div>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-bold text-slate-700 mb-2">Upload Photos (Optional)</label>
                <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:bg-slate-50 transition cursor-pointer">
                   <Camera className="mx-auto text-slate-400 mb-2" />
                   <p className="text-sm text-slate-500">Click to upload photos</p>
                   <input type="file" className="hidden" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-bold text-slate-700 mb-2">Crew Size</label>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 flex items-center gap-4">
                    <div className="bg-white p-2 rounded-full shadow-sm text-blue-600">
                        <Users size={20} />
                    </div>
                    <div>
                        <div className="font-bold text-blue-900">2-Person Crew (Required)</div>
                        <div className="text-xs text-blue-700">For safety and efficiency, all jobs are performed by a team of two.</div>
                    </div>
                </div>
              </div>

              <div className="flex justify-between">
                <button onClick={() => setStep(1)} className="text-slate-500 hover:text-slate-800">Back</button>
                <button 
                  onClick={() => setStep(3)} 
                  disabled={formData.description.length < 5}
                  className="bg-primary-600 text-white px-8 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary-700 transition"
                >
                  Next Step
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <form onSubmit={handleSubmit} className="animate-fadeIn">
              <h2 className="text-2xl font-bold mb-6 text-slate-900">Contact Details</h2>
              
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Full Name</label>
                  <input required type="text" name="contactName" value={formData.contactName} onChange={handleInputChange} className="w-full border rounded-lg p-2" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Phone</label>
                  <input required type="tel" name="contactPhone" value={formData.contactPhone} onChange={handleInputChange} className="w-full border rounded-lg p-2" />
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-bold text-slate-700 mb-1">Email Address</label>
                <input required type="email" name="contactEmail" value={formData.contactEmail} onChange={handleInputChange} className="w-full border rounded-lg p-2" />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-slate-700 mb-1">Service Address (Vaughan/GTA)</label>
                <input required type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full border rounded-lg p-2" />
              </div>

              <div className="mb-6">
                <label className="block text-sm font-bold text-slate-700 mb-1">Preferred Date</label>
                <input type="date" name="preferredDate" value={formData.preferredDate} onChange={handleInputChange} className="w-full border rounded-lg p-2" />
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-6 flex items-start gap-3">
                 <AlertCircle className="text-yellow-600 shrink-0" size={20} />
                 <p className="text-xs text-yellow-800">
                   <strong>Note:</strong> This is a quote request. We will contact you to confirm the final price and date. For immediate booking, please use our Booking page.
                 </p>
              </div>

              <div className="flex justify-between items-center">
                <button type="button" onClick={() => setStep(2)} className="text-slate-500 hover:text-slate-800">Back</button>
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-primary-600 text-white px-8 py-3 rounded-lg font-bold disabled:opacity-50 hover:bg-primary-700 transition flex items-center gap-2"
                >
                  {isSubmitting && <Loader2 className="animate-spin" size={18} />}
                  Submit Request
                </button>
              </div>
            </form>
          )}

          {step === 4 && (
            <div className="text-center py-12 animate-fadeIn">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={40} />
              </div>
              <h2 className="text-3xl font-heading font-bold mb-4 text-slate-900">Quote Received!</h2>
              <p className="text-slate-600 max-w-md mx-auto mb-8">
                Thanks, {formData.contactName}. We've received your request for {formData.serviceType}. Justin or a team member will review it and email you within 24 hours.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                 <Link to="/" className="px-6 py-3 border rounded-lg font-bold text-slate-600 hover:bg-slate-50">Back Home</Link>
                 <Link to="/book" className="px-6 py-3 bg-accent-500 text-white rounded-lg font-bold hover:bg-accent-600 shadow-lg">Book Same-Day Instead</Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Quote;