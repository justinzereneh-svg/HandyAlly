import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import Home from './pages/Home';
import Services from './pages/Services';
import Quote from './pages/Quote';
import Booking from './pages/Booking';
import Payment from './pages/Payment';
import Emergency from './pages/Emergency';
import About from './pages/About';
import Contact from './pages/Contact';
import Gallery from './pages/Gallery';
import Blog from './pages/Blog';
import Loyalty from './pages/Loyalty';

const App = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:id" element={<Services />} /> {/* Simple re-use for demo */}
          <Route path="/quote" element={<Quote />} />
          <Route path="/book" element={<Booking />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/emergency" element={<Emergency />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/loyalty" element={<Loyalty />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;