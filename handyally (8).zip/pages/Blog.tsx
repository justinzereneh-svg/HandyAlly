import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, Tag } from 'lucide-react';
import { BLOG_POSTS } from '../constants';

const Blog = () => {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-heading font-bold mb-4">Handy Tips & Insights</h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Expert advice on home maintenance, DIY projects, and knowing when to call a pro in Vaughan & the GTA.
          </p>
        </div>
      </div>

      {/* Blog Grid */}
      <div className="container mx-auto px-4 -mt-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post) => (
            <div key={post.id} className="bg-white rounded-2xl shadow-lg overflow-hidden group hover:shadow-xl transition duration-300">
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <div className="absolute top-4 left-4 bg-white/90 px-3 py-1 rounded-full text-xs font-bold text-primary-600 shadow flex items-center gap-1">
                  <Tag size={12} /> {post.category}
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                  <Calendar size={12} />
                  {post.date}
                </div>
                <h2 className="text-xl font-bold font-heading text-slate-900 mb-3 leading-tight group-hover:text-primary-600 transition">
                  {post.title}
                </h2>
                <p className="text-slate-600 text-sm mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <button className="text-primary-600 font-bold text-sm flex items-center gap-1 hover:gap-2 transition-all">
                  Read Article <ArrowRight size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="container mx-auto px-4 mt-20">
        <div className="bg-primary-600 rounded-3xl p-8 md:p-12 text-center text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10 transform translate-x-10 -translate-y-10">
            <svg width="200" height="200" viewBox="0 0 200 200" fill="white"><circle cx="100" cy="100" r="100"/></svg>
          </div>
          <h2 className="text-3xl font-bold font-heading mb-4 relative z-10">Don't Miss a Tip!</h2>
          <p className="mb-8 max-w-lg mx-auto text-primary-100 relative z-10">
            Join our monthly newsletter for seasonal home maintenance checklists and exclusive discounts for subscribers.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto relative z-10" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-1 px-6 py-3 rounded-full text-slate-900 focus:outline-none focus:ring-2 focus:ring-accent-400"
            />
            <button className="px-8 py-3 bg-slate-900 text-white rounded-full font-bold hover:bg-slate-800 transition shadow-lg">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Blog;