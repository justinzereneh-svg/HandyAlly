import React from 'react';
import { Link } from 'react-router-dom';
import { Check, Crown, Star, Shield } from 'lucide-react';
import { LOYALTY_TIERS } from '../constants';

const Loyalty = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-500 opacity-10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 border border-white/20 text-yellow-300">
            <Crown size={16} /> HandyAlly Rewards Club
          </div>
          <h1 className="text-4xl md:text-6xl font-heading font-bold mb-6">
            We Reward <span className="text-accent-400">Loyalty</span>.
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-8">
            More than just a handyman. We are your long-term partner for a better home. Join our rewards program and save on every project.
          </p>
          <div className="flex justify-center gap-4">
             <button onClick={() => document.getElementById('tiers')?.scrollIntoView({behavior: 'smooth'})} className="px-8 py-3 bg-white text-slate-900 rounded-full font-bold hover:bg-slate-100 transition">
               View Benefits
             </button>
             <Link to="/book" className="px-8 py-3 bg-accent-500 text-white rounded-full font-bold hover:bg-accent-600 transition shadow-lg shadow-accent-500/20">
               Book & Join
             </Link>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
               <div className="bg-white p-6 rounded-xl shadow-sm">
                  <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">1</div>
                  <h3 className="font-bold text-lg mb-2">Book a Service</h3>
                  <p className="text-slate-600 text-sm">Complete your first job with us to automatically enter the Bronze tier.</p>
               </div>
               <div className="bg-white p-6 rounded-xl shadow-sm">
                  <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">2</div>
                  <h3 className="font-bold text-lg mb-2">Earn Points</h3>
                  <p className="text-slate-600 text-sm">Every dollar spent and every project completed moves you up the ladder.</p>
               </div>
               <div className="bg-white p-6 rounded-xl shadow-sm">
                  <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">3</div>
                  <h3 className="font-bold text-lg mb-2">Unlock Perks</h3>
                  <p className="text-slate-600 text-sm">Get permanent discounts, priority booking, and exclusive seasonal offers.</p>
               </div>
            </div>
          </div>

          {/* Tiers */}
          <div id="tiers" className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {LOYALTY_TIERS.map((tier, index) => (
              <div key={index} className={`relative p-8 rounded-3xl border-2 flex flex-col ${tier.colorClass}`}>
                <div className={`absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${tier.badgeColor}`}>
                  {tier.requirement}
                </div>
                <h3 className="text-2xl font-heading font-bold text-center mb-2 mt-4">{tier.name}</h3>
                <div className="flex-grow">
                  <ul className="space-y-4 mt-6">
                    {tier.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="bg-white rounded-full p-1 mt-0.5 shadow-sm">
                          <Check size={12} className="text-green-600" />
                        </div>
                        <span className="font-medium text-sm">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-8 pt-6 border-t border-current border-opacity-10 text-center">
                  {index === 2 ? (
                    <div className="text-sm font-bold flex items-center justify-center gap-2">
                       <Shield size={16} /> VIP Status
                    </div>
                  ) : (
                    <Link to="/book" className="text-sm font-bold hover:underline">Book to Qualify &rarr;</Link>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ / Banner */}
      <div className="bg-white py-16 container mx-auto px-4 text-center">
        <h2 className="text-2xl font-bold mb-4">Already a client?</h2>
        <p className="text-slate-600 mb-8">You might already be eligible for Silver or Gold status based on your history.</p>
        <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 border-2 border-slate-200 rounded-full font-bold text-slate-700 hover:border-primary-600 hover:text-primary-600 transition">
          Check My Status
        </Link>
      </div>
    </div>
  );
};

export default Loyalty;