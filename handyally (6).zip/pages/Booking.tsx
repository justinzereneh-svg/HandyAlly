import React, { useState, useEffect, useRef } from 'react';
import { Calendar as CalendarIcon, Clock, DollarSign, Users, Check, ArrowRight, ShieldCheck, AlertCircle, MapPin, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BUSINESS_INFO, SERVICES } from '../constants';
import { suggestAddresses } from '../services/gemini';

// --- Extracted Component to fix Focus Issue ---
interface InputFieldProps {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: () => void;
  type?: string;
  placeholder?: string;
  isError?: boolean;
  disabled?: boolean;
}

const InputField = ({ label, value, onChange, onBlur, type = "text", placeholder, isError, disabled }: InputFieldProps) => {
  return (
    <div className="relative">
      <label className="block text-xs font-bold text-slate-500 mb-1">
        {label} <span className="text-red-500">*</span>
      </label>
      <input 
        type={type}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
        disabled={disabled}
        className={`w-full border rounded-lg p-3 focus:ring-2 outline-none transition-colors ${
          isError 
            ? 'border-red-500 bg-red-50 text-red-900 placeholder-red-300 focus:ring-red-200' 
            : 'border-slate-300 focus:ring-primary-500'
        } ${disabled ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : ''}`} 
      />
      {isError && (
        <div className="absolute right-3 top-[2.1rem] text-red-500">
          <AlertCircle size={16} />
        </div>
      )}
    </div>
  );
};

// --- Address Autocomplete Component ---
interface AddressAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onSelect: (address: string, postalCode: string) => void;
  isError?: boolean;
}

const AddressAutocomplete = ({ value, onChange, onSelect, isError }: AddressAutocompleteProps) => {
  const [suggestions, setSuggestions] = useState<{address: string, postalCode: string}[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (value.length > 4 && showDropdown) {
        setIsLoading(true);
        const results = await suggestAddresses(value);
        setSuggestions(results);
        setIsLoading(false);
      }
    }, 800); // Wait 800ms after typing stops

    return () => clearTimeout(timer);
  }, [value, showDropdown]);

  const handleSelect = (item: {address: string, postalCode: string}) => {
    onSelect(item.address, item.postalCode);
    setSuggestions([]);
    setShowDropdown(false);
  };

  return (
    <div className="relative" ref={wrapperRef}>
      <label className="block text-xs font-bold text-slate-500 mb-1">
        Service Address <span className="text-red-500">*</span>
      </label>
      <div className="relative">
        <input 
          type="text"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setShowDropdown(true);
          }}
          placeholder="Start typing address..."
          className={`w-full border rounded-lg p-3 pl-10 focus:ring-2 outline-none transition-colors ${
            isError 
              ? 'border-red-500 bg-red-50 text-red-900 placeholder-red-300 focus:ring-red-200' 
              : 'border-slate-300 focus:ring-primary-500'
          }`}
        />
        <MapPin size={18} className="absolute left-3 top-3.5 text-slate-400" />
        {isLoading && <Loader2 size={18} className="absolute right-3 top-3.5 text-primary-500 animate-spin" />}
      </div>

      {showDropdown && (suggestions.length > 0 || isLoading) && (
        <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-60 overflow-y-auto">
           {isLoading && suggestions.length === 0 && (
             <div className="p-3 text-xs text-slate-500 text-center">Verifying address...</div>
           )}
           {suggestions.map((item, idx) => (
             <button
               key={idx}
               onClick={() => handleSelect(item)}
               className="w-full text-left px-4 py-3 text-sm hover:bg-slate-50 border-b last:border-0 border-slate-50 flex flex-col"
             >
               <span className="font-bold text-slate-800">{item.address}</span>
               <span className="text-xs text-slate-500">{item.postalCode}</span>
             </button>
           ))}
           <div className="bg-slate-50 p-2 text-[10px] text-right text-slate-400">
              Powered by Google Maps Data
           </div>
        </div>
      )}
      
      {isError && (
        <div className="absolute right-3 top-[2.1rem] text-red-500">
          <AlertCircle size={16} />
        </div>
      )}
    </div>
  );
};

const Booking = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [hours, setHours] = useState(2);

  // Step 3 Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientAddress, setClientAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [description, setDescription] = useState('');

  // Validation State (Track if user has tried to submit or touched a field)
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const selectedService = SERVICES.find(s => s.id === selectedServiceId);

  // Generate next 7 days for demo
  const dates = Array.from({length: 7}, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i + 1); // Start tomorrow
    return {
      full: d,
      label: d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
      iso: d.toISOString().split('T')[0]
    };
  });

  const timeSlots = ['08:00 AM', '10:00 AM', '01:00 PM', '03:00 PM'];

  const calculateTotal = () => {
    // Mandatory 2-person crew
    // Cost = Hours * Rate * 2 People
    const total = hours * BUSINESS_INFO.baseRate * 2;
    return total;
  };

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  // Validation Rules
  const errors = {
    firstName: firstName.length < 2,
    lastName: lastName.length < 2,
    email: !clientEmail.includes('@') || !clientEmail.includes('.'),
    phone: clientPhone.length < 10,
    address: clientAddress.length < 5,
    postalCode: postalCode.length < 6,
    description: description.length === 0
  };

  const isFormValid = () => {
    return !Object.values(errors).some(Boolean);
  };

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  const handleAddressSelect = (addr: string, code: string) => {
    setClientAddress(addr);
    setPostalCode(code);
    // Mark as valid/touched
    setTouched(prev => ({ ...prev, address: true, postalCode: true }));
  };

  const handleProceedToPayment = () => {
    // Mark all as touched to show errors if they exist
    setTouched({
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        address: true,
        postalCode: true,
        description: true
    });

    if (!selectedService || !selectedDate || !selectedTime || !isFormValid()) return;
    
    navigate('/payment', {
      state: {
        serviceName: selectedService.title,
        date: selectedDate,
        time: selectedTime,
        hours: hours,
        crewSize: 2,
        rate: BUSINESS_INFO.baseRate,
        total: calculateTotal(),
        client: {
          firstName,
          lastName,
          email: clientEmail,
          phone: clientPhone,
          address: clientAddress,
          postalCode,
          notes: description
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-heading font-bold text-center mb-8">Book Your Service</h1>
        
        {/* Progress Indicator */}
        <div className="max-w-5xl mx-auto mb-8 flex justify-between items-center px-4 text-xs md:text-sm font-bold text-slate-400 uppercase tracking-wider">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary-600' : ''}`}>
                <span className={`w-6 h-6 rounded-full flex items-center justify-center border ${step >= 1 ? 'bg-primary-600 text-white border-primary-600' : 'border-slate-300'}`}>1</span> Service
            </div>
            <div className="flex-1 h-0.5 bg-slate-200 mx-2"></div>
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary-600' : ''}`}>
                <span className={`w-6 h-6 rounded-full flex items-center justify-center border ${step >= 2 ? 'bg-primary-600 text-white border-primary-600' : 'border-slate-300'}`}>2</span> Time
            </div>
            <div className="flex-1 h-0.5 bg-slate-200 mx-2"></div>
            <div className={`flex items-center gap-2 ${step >= 3 ? 'text-primary-600' : ''}`}>
                <span className={`w-6 h-6 rounded-full flex items-center justify-center border ${step >= 3 ? 'bg-primary-600 text-white border-primary-600' : 'border-slate-300'}`}>3</span> Details
            </div>
        </div>

        <div className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8">
          {/* Left Col: Configuration */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Step 1: Service Selection */}
            {step === 1 && (
                <div className="bg-white p-6 rounded-xl shadow-sm animate-fadeIn">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-slate-800">
                        Select a Service
                    </h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                        {SERVICES.map((service) => (
                            <div 
                                key={service.id}
                                onClick={() => setSelectedServiceId(service.id)}
                                className={`relative border-2 rounded-xl p-5 cursor-pointer transition-all hover:shadow-md ${selectedServiceId === service.id ? 'border-primary-600 bg-primary-50 ring-1 ring-primary-600' : 'border-slate-100 hover:border-primary-200'}`}
                            >
                                <div className="absolute top-0 right-0 bg-accent-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg rounded-tr-lg shadow-sm">
                                    $125/HR
                                </div>
                                <h3 className="font-bold text-slate-900 mb-1">{service.title}</h3>
                                <p className="text-xs text-slate-500 line-clamp-2">{service.shortDescription}</p>
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 flex justify-end">
                        <button 
                            onClick={nextStep} 
                            disabled={!selectedServiceId}
                            className="bg-primary-600 text-white px-8 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary-700 transition flex items-center gap-2"
                        >
                            Continue <ArrowRight size={18} />
                        </button>
                    </div>
                </div>
            )}

            {/* Step 2: Date & Time */}
            {step === 2 && (
                <div className="bg-white p-6 rounded-xl shadow-sm animate-fadeIn">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><CalendarIcon size={20} className="text-primary-600"/> Select Date & Time</h2>
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-6">
                        {dates.map(d => (
                        <button 
                            key={d.iso} 
                            onClick={() => setSelectedDate(d.iso)}
                            className={`p-3 rounded-lg border text-sm text-center transition ${selectedDate === d.iso ? 'bg-primary-600 text-white border-primary-600' : 'hover:border-primary-400'}`}
                        >
                            {d.label}
                        </button>
                        ))}
                    </div>
                
                    {selectedDate && (
                        <div className="animate-fadeIn">
                            <p className="text-sm font-bold mb-2">Available Slots for {selectedDate}</p>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                {timeSlots.map(t => (
                                <button 
                                    key={t}
                                    onClick={() => setSelectedTime(t)}
                                    className={`p-2 rounded border text-sm ${selectedTime === t ? 'bg-accent-500 text-white border-accent-500' : 'bg-slate-50 hover:bg-slate-100'}`}
                                >
                                    {t}
                                </button>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    <div className="mt-6 flex justify-between">
                        <button onClick={prevStep} className="text-slate-500 font-medium hover:text-slate-900">Back</button>
                        <button 
                            onClick={nextStep} 
                            disabled={!selectedDate || !selectedTime}
                            className="bg-primary-600 text-white px-8 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary-700 transition flex items-center gap-2"
                        >
                            Continue <ArrowRight size={18} />
                        </button>
                    </div>
                </div>
            )}

            {/* Step 3: Job Details */}
            {step === 3 && (
                <div className="bg-white p-6 rounded-xl shadow-sm animate-fadeIn">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Clock size={20} className="text-primary-600"/> Duration & Safety</h2>
                    
                    <div className="mb-6">
                        <label className="block text-sm font-bold mb-2">Estimated Duration (Hours)</label>
                        <div className="flex items-center gap-4">
                        <input 
                            type="range" 
                            min="2" 
                            max="8" 
                            step="1" 
                            value={hours} 
                            onChange={(e) => setHours(parseInt(e.target.value))}
                            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="font-bold text-2xl w-12">{hours}h</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-2">Minimum 2 hours. Overtime billed at 1.5x.</p>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 flex items-start gap-4 mb-6">
                        <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-blue-600 border shrink-0">
                            <ShieldCheck size={20} />
                        </div>
                        <div>
                            <p className="font-bold text-blue-900">Safety First Policy</p>
                            <p className="text-sm text-blue-800 mt-1">
                                To ensure safety and efficiency, <span className="font-bold underline">all jobs require a minimum of 2 handy people</span>. 
                                Your quote includes this mandatory 2-person crew.
                            </p>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                           <InputField 
                              label="First Name"
                              value={firstName}
                              onChange={(e) => setFirstName(e.target.value)}
                              onBlur={() => handleBlur('firstName')}
                              placeholder="John"
                              isError={touched.firstName && errors.firstName}
                           />
                           <InputField 
                              label="Last Name"
                              value={lastName}
                              onChange={(e) => setLastName(e.target.value)}
                              onBlur={() => handleBlur('lastName')}
                              placeholder="Doe"
                              isError={touched.lastName && errors.lastName}
                           />
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <InputField 
                              label="Phone Number"
                              type="tel"
                              value={clientPhone}
                              onChange={(e) => setClientPhone(e.target.value)}
                              onBlur={() => handleBlur('phone')}
                              placeholder="(647) 555-0199"
                              isError={touched.phone && errors.phone}
                          />
                          <InputField 
                              label="Email Address"
                              type="email"
                              value={clientEmail}
                              onChange={(e) => setClientEmail(e.target.value)}
                              onBlur={() => handleBlur('email')}
                              placeholder="john@example.com"
                              isError={touched.email && errors.email}
                          />
                        </div>

                        <div className="grid md:grid-cols-3 gap-4">
                            <div className="md:col-span-2">
                                {/* Replaced with Address Autocomplete */}
                                <AddressAutocomplete 
                                   value={clientAddress}
                                   onChange={setClientAddress}
                                   onSelect={handleAddressSelect}
                                   isError={touched.address && errors.address}
                                />
                            </div>
                            <div>
                                <InputField 
                                    label="Postal Code"
                                    value={postalCode}
                                    onChange={(e) => setPostalCode(e.target.value)}
                                    onBlur={() => handleBlur('postalCode')}
                                    placeholder="L4K 1A1"
                                    isError={touched.postalCode && errors.postalCode}
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1">
                                Project Description <span className="text-red-500">*</span>
                            </label>
                            <textarea 
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                onBlur={() => handleBlur('description')}
                                placeholder="Brief description of work needed..." 
                                className={`w-full border rounded-lg p-3 focus:ring-2 outline-none transition-colors ${
                                    touched.description && description.length === 0
                                    ? 'border-red-500 bg-red-50' 
                                    : 'border-slate-300 focus:ring-primary-500'
                                }`}
                                rows={3}
                            ></textarea>
                            {touched.description && description.length === 0 && (
                                <p className="text-xs text-red-500 mt-1">Please provide a description.</p>
                            )}
                        </div>
                    </div>

                    <div className="mt-6 flex justify-between">
                        <button onClick={prevStep} className="text-slate-500 font-medium hover:text-slate-900">Back</button>
                    </div>
                </div>
            )}

          </div>

          {/* Right Col: Summary & Checkout */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white p-6 rounded-xl shadow-xl border border-slate-100">
               <h3 className="font-bold text-lg mb-4 border-b pb-2">Booking Summary</h3>
               
               <div className="space-y-3 mb-6 text-sm">
                 <div className="flex justify-between">
                   <span className="text-slate-500">Service:</span>
                   <span className="font-medium text-right">{selectedService?.title || 'Select...'}</span>
                 </div>
                 <div className="flex justify-between">
                   <span className="text-slate-500">Date:</span>
                   <span className="font-medium">{selectedDate || '-'}</span>
                 </div>
                 <div className="flex justify-between">
                   <span className="text-slate-500">Time:</span>
                   <span className="font-medium">{selectedTime || '-'}</span>
                 </div>
                 
                 <div className="border-t border-dashed pt-2 mt-2"></div>

                 <div className="flex justify-between">
                    <span className="text-slate-500">Crew Size:</span>
                    <span className="font-bold text-slate-800 flex items-center gap-1"><Users size={14}/> 2 People (Required)</span>
                 </div>
                 <div className="flex justify-between">
                   <span className="text-slate-500">Rate per Person:</span>
                   <span className="font-medium">${BUSINESS_INFO.baseRate}/hr</span>
                 </div>
                 <div className="flex justify-between">
                   <span className="text-slate-500">Duration:</span>
                   <span className="font-medium">{hours} Hours</span>
                 </div>
               </div>

               <div className="border-t pt-4 mb-6">
                 <div className="flex justify-between items-end">
                   <span className="font-bold text-slate-900 text-lg">Total Est:</span>
                   <span className="font-bold text-3xl text-primary-600">${calculateTotal()}</span>
                 </div>
                 <p className="text-xs text-slate-400 mt-1 text-center">*Includes 2 Handymen for {hours} hours</p>
               </div>

               {step === 3 ? (
                    <div className="space-y-2">
                        <button 
                            onClick={handleProceedToPayment}
                            className="w-full bg-accent-500 hover:bg-accent-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg transition flex items-center justify-center gap-2"
                        >
                            Confirm Booking <DollarSign size={18}/>
                        </button>
                        {!isFormValid() && Object.keys(touched).length > 0 && (
                            <p className="text-xs text-red-500 text-center font-bold animate-pulse">Please fix the errors marked in red.</p>
                        )}
                    </div>
               ) : (
                   <button disabled className="w-full bg-slate-200 text-slate-400 py-4 rounded-xl font-bold text-lg cursor-not-allowed">
                       Complete Steps
                   </button>
               )}

               <div className="mt-4 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                 <Check size={12}/> Secure SSL Payment
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Booking;
