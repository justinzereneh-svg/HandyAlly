import React from 'react';
import { Phone, Clock, ShieldAlert, MapPin } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Emergency = () => {
  return (
    <div className="min-h-screen bg-red-50">
      {/* Urgent Banner */}
      <div className="bg-red-600 text-white text-center py-3 px-4 font-bold animate-pulse">
        ⚠️ EMERGENCY SERVICE ACTIVE: 60-120 MINUTE RESPONSE TIME AVAILABLE
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden border-2 border-red-100">
           <div className="p-8 md:p-12 text-center">
              <div className="inline-block p-4 bg-red-100 text-red-600 rounded-full mb-6">
                <ShieldAlert size={48} />
              </div>
              <h1 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-4">
                Emergency Repair Service
              </h1>
              <p className="text-xl text-slate-600 mb-8">
                Water leak? Security breach? Electrical hazard?<br/> 
                We prioritize your safety with rapid dispatch in Vaughan & GTA.
              </p>

              <div className="bg-slate-900 rounded-2xl p-8 mb-8 shadow-lg">
                <p className="text-slate-400 text-sm uppercase tracking-widest mb-2">Call Justin Immediately</p>
                <a href={`tel:${BUSINESS_INFO.phone}`} className="text-3xl md:text-5xl font-bold text-white flex items-center justify-center gap-3 hover:text-accent-500 transition">
                   <Phone size={32} className="md:w-10 md:h-10" />
                   {BUSINESS_INFO.phone}
                </a>
                <p className="text-slate-400 text-sm mt-2">Click number to dial</p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 text-left">
                <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                   <Clock className="text-red-500 mb-3" size={24} />
                   <h3 className="font-bold text-slate-900 mb-1">Fast Arrival</h3>
                   <p className="text-sm text-slate-600">We aim for 60-120 minutes arrival windows for emergency calls.</p>
                </div>
                <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                   <MapPin className="text-red-500 mb-3" size={24} />
                   <h3 className="font-bold text-slate-900 mb-1">Local Dispatch</h3>
                   <p className="text-sm text-slate-600">Dispatched directly from Vaughan/Woodbridge for speed.</p>
                </div>
                <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                   <ShieldAlert className="text-red-500 mb-3" size={24} />
                   <h3 className="font-bold text-slate-900 mb-1">Premium Rate</h3>
                   <p className="text-sm text-slate-600">Emergency dispatch fees apply. Upfront pricing before work starts.</p>
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Emergency;