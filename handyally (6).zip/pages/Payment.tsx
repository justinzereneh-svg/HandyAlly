import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { CreditCard, Lock, ShieldCheck, CheckCircle, ArrowLeft, Loader2, AlertCircle, Mail } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';
import emailjs from '@emailjs/browser';

// --- EMAILJS CONFIGURATION ---
const EMAILJS_SERVICE_ID = 'service_5swvedg';
const EMAILJS_TEMPLATE_ID = 'template_mz48nth';
const EMAILJS_PUBLIC_KEY = '-iXRvixkGdCWlRe65'; 
// -----------------------------

export default function Payment() {
  const location = useLocation();
  const bookingData = location.state;
  
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Card Form State
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [nameOnCard, setNameOnCard] = useState('');
  const [postalCode, setPostalCode] = useState('');

  // Pre-fill data if available from booking
  useEffect(() => {
    if (bookingData?.client) {
        setNameOnCard(`${bookingData.client.firstName} ${bookingData.client.lastName}`);
        if (bookingData.client.postalCode) {
            setPostalCode(bookingData.client.postalCode);
        }
    }
  }, [bookingData]);

  if (!bookingData) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col p-4">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Session Expired</h2>
        <p className="mb-6 text-slate-600">Please restart your booking.</p>
        <Link to="/book" className="bg-primary-600 text-white px-6 py-3 rounded-lg font-bold">Back to Booking</Link>
      </div>
    );
  }

  const validateCard = () => {
    const numRegex = /^\d{16}$/; 
    const cvcRegex = /^\d{3,4}$/; 
    const expiryRegex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/; 
    if (!postalCode) return "Postal code required";

    if (!numRegex.test(cardNumber.replace(/\s/g, ''))) return "Invalid Card Number. Must be 16 digits.";
    if (!expiryRegex.test(expiry)) return "Invalid Expiry. Use MM/YY format.";
    if (!cvcRegex.test(cvc)) return "Invalid CVC. Must be 3 or 4 digits.";
    if (nameOnCard.length < 3) return "Please enter the name exactly as on the card.";

    return null;
  };

  // Generate a professional HTML email structure
  const generateEmailHTML = () => {
    const totalPrice = (bookingData.total * 1.13).toFixed(2);
    const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #334155; line-height: 1.6; margin: 0; padding: 0; background-color: #f1f5f9; }
          .wrapper { width: 100%; background-color: #f1f5f9; padding: 40px 0; }
          .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
          .header { background-color: #1e3a8a; padding: 40px 30px; text-align: center; }
          .logo { font-size: 28px; font-weight: 800; color: #ffffff; margin-bottom: 8px; letter-spacing: -1px; }
          .subtitle { color: #bfdbfe; font-size: 14px; text-transform: uppercase; letter-spacing: 2px; font-weight: 600; }
          .content { padding: 40px 30px; }
          .greeting { font-size: 18px; margin-bottom: 20px; color: #0f172a; }
          .message { margin-bottom: 30px; color: #475569; }
          
          .card { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
          .card-title { font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #e2e8f0; }
          
          .row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px; }
          .row:last-child { margin-bottom: 0; }
          .label { color: #64748b; }
          .value { font-weight: 600; color: #0f172a; text-align: right; }
          
          .total-section { background-color: #eff6ff; border: 1px solid #dbeafe; border-radius: 12px; padding: 25px; text-align: center; margin-top: 30px; }
          .total-label { color: #1e40af; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 5px; }
          .total-amount { color: #1e3a8a; font-size: 36px; font-weight: 800; }
          .payment-status { display: inline-block; background-color: #dcfce7; color: #166534; font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 99px; margin-top: 10px; }
          
          .footer { background-color: #1e293b; color: #94a3b8; padding: 30px; text-align: center; font-size: 12px; }
          .footer-link { color: #f8fafc; text-decoration: none; font-weight: 600; }
          .divider { border-top: 1px solid #334155; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="wrapper">
          <div class="container">
            <div class="header">
              <div class="logo">HandyAlly</div>
              <div class="subtitle">Booking Confirmation</div>
            </div>
            
            <div class="content">
              <div class="greeting">Hello ${bookingData.client.firstName},</div>
              <div class="message">
                Your booking has been successfully received! Our team is scheduled to arrive on the date below.
              </div>

              <div class="card">
                <div class="card-title">Service Details</div>
                <div class="row">
                  <span class="label">Service</span>
                  <span class="value">${bookingData.serviceName}</span>
                </div>
                <div class="row">
                  <span class="label">Date</span>
                  <span class="value">${bookingData.date}</span>
                </div>
                <div class="row">
                  <span class="label">Time</span>
                  <span class="value">${bookingData.time}</span>
                </div>
                 <div class="row">
                  <span class="label">Duration</span>
                  <span class="value">${bookingData.hours} Hours (2 Crew)</span>
                </div>
                <div class="row">
                   <span class="label">Address</span>
                   <span class="value">${bookingData.client.address}</span>
                </div>
              </div>

              <div class="card">
                <div class="card-title">Customer Contact</div>
                <div class="row">
                  <span class="label">Name</span>
                  <span class="value">${bookingData.client.firstName} ${bookingData.client.lastName}</span>
                </div>
                <div class="row">
                  <span class="label">Email</span>
                  <span class="value">${bookingData.client.email}</span>
                </div>
                <div class="row">
                  <span class="label">Phone</span>
                  <span class="value">${bookingData.client.phone}</span>
                </div>
              </div>

              ${bookingData.client.notes ? `
              <div class="card">
                <div class="card-title">Work Notes</div>
                <p style="font-size: 14px; margin: 0;">${bookingData.client.notes}</p>
              </div>
              ` : ''}

              <div class="total-section">
                <div class="total-label">Total Charged</div>
                <div class="total-amount">$${totalPrice}</div>
                <div class="payment-status">PAID VIA CREDIT CARD</div>
              </div>
            </div>

            <div class="footer">
              <p style="margin-bottom: 10px;">Need to reschedule? Call us at <strong>647-451-6961</strong></p>
              <p>Sent on ${dateStr}</p>
              <div class="divider"></div>
              <p>&copy; ${new Date().getFullYear()} HandyAlly. Vaughan, Ontario.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  };

  const sendEmail = async () => {
    const htmlContent = generateEmailHTML();
    
    // We construct a recipient string that includes:
    // 1. The Client
    // 2. The Business Email (justinzereneh@handyally.com)
    // 3. The Personal/Backup Email (justinzereneh@outlook.com)
    const recipients = [
        bookingData.client.email,
        "justinzereneh@handyally.com",
        "justinzereneh@outlook.com"
    ].join(',');

    const templateParams = {
      service_name: bookingData.serviceName,
      client_name: `${bookingData.client.firstName} ${bookingData.client.lastName}`,
      html_message: htmlContent,
      // Fallback text message
      message: `New Booking Confirmed\nService: ${bookingData.serviceName}\nDate: ${bookingData.date} @ ${bookingData.time}\nClient: ${bookingData.client.firstName} ${bookingData.client.lastName}`,
      to_name: `${bookingData.client.firstName} ${bookingData.client.lastName}`,
      // Sends to all parties
      to_email: recipients,
      reply_to: bookingData.client.email
    };

    try {
        await emailjs.send(
            EMAILJS_SERVICE_ID, 
            EMAILJS_TEMPLATE_ID, 
            templateParams, 
            EMAILJS_PUBLIC_KEY
        );
    } catch (err) {
        console.error("EmailJS Error:", err);
    } finally {
        setIsSuccess(true);
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    const validationError = validateCard();
    if (validationError) {
        setError(validationError);
        return;
    }

    setIsProcessing(true);
    await sendEmail();
    setIsProcessing(false);
  };

  const handlePayPalClick = async () => {
      setIsProcessing(true);
      await sendEmail();
      setIsProcessing(false);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl max-w-lg text-center animate-fadeIn">
          <div className="w-24 h-24 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={48} />
          </div>
          <h1 className="text-3xl font-heading font-bold text-slate-900 mb-4">Booking Confirmed!</h1>
          <p className="text-slate-600 mb-6">
            Thank you, <strong>{bookingData.client?.firstName}</strong>. Your booking has been received.
            <br />
            <span className="text-sm text-slate-500 bg-yellow-50 px-2 py-1 rounded mt-2 inline-block border border-yellow-100">
               Note: Please check your Spam/Junk folder for the confirmation email.
            </span>
          </p>
          
          <div className="bg-blue-50 border border-blue-200 p-6 rounded-xl mb-6 text-left">
             <p className="font-bold text-blue-900 mb-3 flex items-center gap-2">
                 <Mail size={16}/> Notification Status
             </p>
             <div className="space-y-3 text-sm text-blue-800">
                 <div className="flex items-start gap-2">
                     <CheckCircle size={14} className="mt-1 shrink-0 text-green-600" />
                     <div>
                        <p className="font-bold">Confirmation Sent</p>
                        <p className="text-xs opacity-75">To: {bookingData.client?.email}</p>
                     </div>
                 </div>
                 <div className="flex items-start gap-2">
                     <CheckCircle size={14} className="mt-1 shrink-0 text-green-600" />
                     <div>
                        <p className="font-bold">Office Alert Sent</p>
                        <p className="text-xs opacity-75">To: HandyAlly Dispatch</p>
                     </div>
                 </div>
             </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl mb-8 text-left border border-slate-100">
            <p className="text-sm text-slate-500 mb-1">Transaction ID</p>
            <p className="font-mono font-bold text-slate-800">#ORD-{Math.floor(Math.random() * 100000)}</p>
          </div>
          <Link to="/" className="block w-full bg-primary-600 text-white py-4 rounded-xl font-bold hover:bg-primary-700 transition">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="flex justify-between items-center mb-6">
             <Link to="/book" className="inline-flex items-center text-slate-500 hover:text-slate-800 font-medium">
               <ArrowLeft size={18} className="mr-1" /> Back to Booking
             </Link>
             <div className="text-xs font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full flex items-center gap-1">
                <Lock size={12} /> Secure Connection
             </div>
        </div>

        <h1 className="text-3xl font-heading font-bold text-slate-900 mb-8">Secure Payment</h1>

        <div className="grid md:grid-cols-3 gap-8">
          
          {/* Payment Form */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="flex border-b">
                <button 
                  onClick={() => setPaymentMethod('card')}
                  className={`flex-1 py-4 font-bold text-sm flex items-center justify-center gap-2 ${paymentMethod === 'card' ? 'bg-white text-primary-600 border-b-2 border-primary-600' : 'bg-slate-50 text-slate-500'}`}
                >
                  <CreditCard size={18} /> Credit Card
                </button>
                <button 
                  onClick={() => setPaymentMethod('paypal')}
                  className={`flex-1 py-4 font-bold text-sm flex items-center justify-center gap-2 ${paymentMethod === 'paypal' ? 'bg-white text-primary-600 border-b-2 border-primary-600' : 'bg-slate-50 text-slate-500'}`}
                >
                  <span className="font-serif italic font-black text-blue-800">Pay</span><span className="font-serif italic font-black text-blue-500">Pal</span>
                </button>
              </div>

              <div className="p-8">
                {paymentMethod === 'card' && (
                  <form onSubmit={handlePayment} className="space-y-6">
                    
                    {error && (
                        <div className="bg-red-50 text-red-600 p-4 rounded-lg text-sm font-bold flex items-center gap-2">
                            <AlertCircle size={16}/> {error}
                        </div>
                    )}

                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Card Number</label>
                      <div className="relative">
                        <input 
                            type="text" 
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            placeholder="0000 0000 0000 0000" 
                            className="w-full border rounded-lg pl-12 pr-4 py-3 focus:ring-2 focus:ring-primary-500 focus:outline-none" 
                        />
                        <CreditCard className="absolute left-4 top-3.5 text-slate-400" size={20} />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Expiry Date</label>
                        <input 
                            type="text" 
                            value={expiry}
                            onChange={(e) => setExpiry(e.target.value)}
                            placeholder="MM / YY" 
                            className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary-500 focus:outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">CVC</label>
                        <input 
                            type="text" 
                            value={cvc}
                            onChange={(e) => setCvc(e.target.value)}
                            placeholder="123" 
                            maxLength={4}
                            className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary-500 focus:outline-none" 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 mb-2">Cardholder Name</label>
                            <input 
                                type="text" 
                                value={nameOnCard}
                                onChange={(e) => setNameOnCard(e.target.value)}
                                placeholder="Full Name" 
                                className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary-500 focus:outline-none" 
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 mb-2">Postal Code</label>
                            <input 
                                type="text" 
                                value={postalCode}
                                onChange={(e) => setPostalCode(e.target.value)}
                                placeholder="A1A 1A1" 
                                className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary-500 focus:outline-none" 
                            />
                        </div>
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit" 
                        disabled={isProcessing}
                        className="w-full bg-primary-600 hover:bg-primary-700 text-white py-4 rounded-xl font-bold shadow-lg transition flex items-center justify-center gap-2"
                      >
                        {isProcessing ? <Loader2 className="animate-spin" /> : <Lock size={18} />}
                        {isProcessing ? 'Processing...' : `Pay $${(bookingData.total * 1.13).toFixed(2)}`}
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center gap-2 text-xs text-slate-400 mt-4">
                      <ShieldCheck size={14} /> Bank-level 256-bit encryption
                    </div>
                  </form>
                )}

                {paymentMethod === 'paypal' && (
                   <div className="text-center py-8">
                      <p className="text-slate-600 mb-6">You will be redirected to PayPal to securely complete your payment.</p>
                      <button 
                        onClick={handlePayPalClick}
                        disabled={isProcessing}
                        className="w-full bg-[#FFC439] hover:bg-[#f4bb36] text-blue-900 font-bold py-4 rounded-xl shadow-md flex items-center justify-center gap-2"
                      >
                        {isProcessing ? <Loader2 className="animate-spin" /> : null}
                        Pay with <span className="font-serif italic font-black">PayPal</span>
                      </button>
                   </div>
                )}
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="md:col-span-1">
             <div className="bg-white rounded-2xl shadow-sm p-6 border border-slate-100 sticky top-8">
               <h3 className="text-lg font-bold text-slate-800 mb-4 pb-2 border-b">Order Summary</h3>
               
               <div className="space-y-4 mb-6">
                 <div>
                   <p className="text-xs text-slate-500">Service</p>
                   <p className="font-bold text-slate-900">{bookingData.serviceName}</p>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs text-slate-500">Date</p>
                      <p className="font-bold text-slate-900">{bookingData.date}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Time</p>
                      <p className="font-bold text-slate-900">{bookingData.time}</p>
                    </div>
                 </div>

                 <div>
                    <p className="text-xs text-slate-500">Duration & Crew</p>
                    <p className="font-medium text-slate-700">{bookingData.hours} Hours x {bookingData.crewSize} People</p>
                 </div>

                 <div className="bg-slate-50 p-2 rounded border border-slate-100">
                    <p className="text-xs text-slate-500">Client</p>
                    <p className="font-bold text-xs text-slate-800">{bookingData.client?.firstName} {bookingData.client?.lastName}</p>
                    <p className="text-xs text-slate-600">{bookingData.client?.email}</p>
                    <p className="text-xs text-slate-600">{bookingData.client?.phone}</p>
                    <p className="text-xs text-slate-600">{bookingData.client?.postalCode}</p>
                 </div>
               </div>

               <div className="border-t pt-4">
                 <div className="flex justify-between items-center mb-2">
                   <span className="text-slate-600">Subtotal</span>
                   <span className="font-medium">${bookingData.total}</span>
                 </div>
                 <div className="flex justify-between items-center mb-4">
                   <span className="text-slate-600">HST (13%)</span>
                   <span className="font-medium">${(bookingData.total * 0.13).toFixed(2)}</span>
                 </div>
                 <div className="flex justify-between items-end pt-2 border-t border-dashed">
                   <span className="font-bold text-slate-900">Total</span>
                   <span className="font-bold text-3xl text-primary-600">${(bookingData.total * 1.13).toFixed(2)}</span>
                 </div>
               </div>
             </div>
          </div>

        </div>
      </div>
    );
  }
}