import React from 'react';
import { Phone, Mail, Clock, MapPin } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Contact = () => {
  return (
    <div className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
         <h1 className="text-4xl font-heading font-bold text-center mb-12">Get In Touch</h1>
         
         <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
            {/* Info */}
            <div className="bg-white p-8 rounded-2xl shadow-sm h-full">
              <h2 className="text-2xl font-bold mb-6">Contact Info</h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                   <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 shrink-0">
                     <Phone />
                   </div>
                   <div>
                     <h3 className="font-bold text-slate-900">Phone</h3>
                     <p className="text-slate-500 mb-1">Mon-Fri 8am-6pm</p>
                     <a href={`tel:${BUSINESS_INFO.phone}`} className="text-xl font-bold text-primary-600">{BUSINESS_INFO.phone}</a>
                   </div>
                </div>

                <div className="flex items-start gap-4">
                   <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 shrink-0">
                     <Mail />
                   </div>
                   <div>
                     <h3 className="font-bold text-slate-900">Email</h3>
                     <p className="text-slate-500 mb-1">Quotes & Inquiries</p>
                     <a href={`mailto:${BUSINESS_INFO.email}`} className="text-lg font-bold text-primary-600 break-all">{BUSINESS_INFO.email}</a>
                   </div>
                </div>

                <div className="flex items-start gap-4">
                   <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 shrink-0">
                     <MapPin />
                   </div>
                   <div>
                     <h3 className="font-bold text-slate-900">Service Area</h3>
                     <p className="text-slate-500">Based in Vaughan, ON.</p>
                     <p className="text-slate-500">Serving Woodbridge, Kleinburg, Concord, Maple, and surrounding GTA.</p>
                   </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-slate-900 text-white rounded-xl">
                 <h3 className="font-bold mb-2">Operating Hours</h3>
                 <ul className="text-sm space-y-2 text-slate-300">
                   <li className="flex justify-between"><span>Monday - Friday</span> <span>8:00 AM - 6:00 PM</span></li>
                   <li className="flex justify-between"><span>Saturday</span> <span>9:00 AM - 4:00 PM</span></li>
                   <li className="flex justify-between text-red-400 font-bold"><span>Sunday / Emergency</span> <span>On Call</span></li>
                 </ul>
              </div>
            </div>

            {/* Visual Map Placeholder */}
            <div className="bg-slate-200 rounded-2xl h-96 md:h-full overflow-hidden relative shadow-inner group">
               <img 
                 src="https://picsum.photos/id/1048/800/800" 
                 className="w-full h-full object-cover grayscale opacity-50 group-hover:opacity-75 transition duration-500" 
                 alt="Map Background" 
               />
               <div className="absolute inset-0 flex items-center justify-center">
                 <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl text-center shadow-xl">
                   <MapPin className="mx-auto text-primary-600 mb-2" size={32} />
                   <p className="font-bold text-slate-900">Serving Vaughan & GTA</p>
                   <p className="text-xs text-slate-500 mt-1">We come to you fully equipped.</p>
                 </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Contact;